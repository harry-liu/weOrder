/**
 * Created by harry-liu on 2017/4/7.
 */
export const API_ROOT = 'http://wdc-api.xabdsy.cn/v1/'