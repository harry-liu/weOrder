/**
 * Created by harry-liu on 2017/4/3.
 */
import Vue from 'vue'

Vue.directive('div-on-show',function (el,binding) {
    window.onscroll = function() {

    };
});