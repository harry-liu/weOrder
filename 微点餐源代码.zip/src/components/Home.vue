<template>
    <div style="margin-top: 200px;font-size: 20px;">
        <router-link to="/take-away">打包</router-link>
        <router-link to="/have-in">到店吃</router-link>
        <router-link to="/pre-order">预点餐</router-link>
        <router-link to="/member-center">会员中心</router-link>
        <router-link to="/pay-online">在线支付</router-link>
        <router-link to="/my-orders">我的订单</router-link>
        <router-link to="/instead-pay">代支付</router-link>
        <router-link to="/charge">充值</router-link>
    </div>
</template>

<script>
    export default{
        name:'home'
    }
</script>

<style>

</style>